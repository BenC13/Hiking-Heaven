/*
* Copyright (C) 2021 The Android Open Source Project.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.example.dogglers

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.dogglers.data.DataSource
import com.example.dogglers.data.DataSource.pics
import com.example.dogglers.databinding.ActivityGridListBinding
import com.example.dogglers.model.Hike

class GridListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGridListBinding
    private lateinit var listIntent: Intent

    private lateinit var locationField: EditText
    private lateinit var milesField: EditText
    private lateinit var elevationField: EditText
    private lateinit var weightField: EditText

    private lateinit var hike: Hike

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGridListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        locationField = findViewById(R.id.get_location)
        milesField = findViewById(R.id.get_distance)
        elevationField = findViewById(R.id.get_elevation)
        weightField = findViewById(R.id.get_weight)

        binding.addButton.setOnClickListener { addHike() }

        binding.cancelButton.setOnClickListener { goBack() }

        // Enable up button for backward navigation
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }
    private fun goBack(){
        listIntent = Intent(this, MainActivity::class.java)
        startActivity(listIntent)
    }

    private fun addHike() {
        val location = locationField.getText()
        val miles = milesField.getText()
        val elevation = elevationField.getText()
        val weight = weightField.getText()

//        var nextFree = 0
//        var cont = true
//
//        while(cont){
//            if(com.example.dogglers.data.DataSource.hikes[nextFree].location == ""){
//                cont = false
//            }else{
//                nextFree += 1
//            }
//            if(nextFree > 10){
//                Log.v("MainActivity", "&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
//            }
//        }
//
//        Log.v("MainActivity", "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%$nextFree")
//
//
//        com.example.dogglers.data.DataSource.hikes[nextFree].location = location.toString()
//        com.example.dogglers.data.DataSource.hikes[nextFree].miles = miles.toString()
//        com.example.dogglers.data.DataSource.hikes[nextFree].elevation = elevation.toString()
//        com.example.dogglers.data.DataSource.hikes[nextFree].weight = weight.toString()


        val image = pics.get(0)
        pics.removeAt(0)

        if(pics.size == 0){
            Toast.makeText(applicationContext,"No More Space!!",Toast.LENGTH_SHORT).show()
        }else{
            hike = Hike(
                image,
                location.toString(),
                miles.toString(),
                elevation.toString(),
                weight.toString()

            )

            DataSource.hikes.add(hike)


            listIntent = Intent(this, VerticalListActivity::class.java)
            startActivity(listIntent)
        }





    }

}
