/*
* Copyright (C) 2021 The Android Open Source Project.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.example.dogglers

import android.app.LauncherActivity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.example.dogglers.adapter.HikeCardAdapter
import com.example.dogglers.const.Layout
import com.example.dogglers.databinding.ActivityVerticalListBinding
import com.example.dogglers.databinding.GridListItemBinding
import com.example.dogglers.databinding.ListItemBinding

class VerticalListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityVerticalListBinding
    private lateinit var binding2: ListItemBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityVerticalListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.verticalRecyclerView.adapter = HikeCardAdapter(
            applicationContext,
            Layout.VERTICAL
        )

        binding2 = ListItemBinding.inflate(layoutInflater)
        binding2.export.setOnClickListener { export() }



        // Specify fixed size to improve performance
        binding.verticalRecyclerView.setHasFixedSize(true)

        // Enable up button for backward navigation
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    private fun export(){
        Log.v("MainActivity", "##################################################")
        val hikes = com.example.dogglers.data.DataSource.hikes
        val hikeSummary = hikes[0].location + "/n" + hikes[0].miles + "/n" + hikes[0].elevation + "/n" + hikes[0].weight



        val intent = Intent(Intent.ACTION_SEND)
            .setType("text/plain")
            .putExtra(Intent.EXTRA_TITLE, "My Hike:")
            .putExtra(Intent.EXTRA_TEXT, hikeSummary)


        startActivity(intent)

    }
}
